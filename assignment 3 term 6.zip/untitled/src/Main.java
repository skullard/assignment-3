import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        GroceryList gl = new GroceryList();
        GroceryitemOrder I1 = new GroceryitemOrder("pineapple", 99.5);
        I1.setitemQuantity(2);
        gl.add(I1);

        GroceryitemOrder I2 = new GroceryitemOrder("0",6.0);
        I2.setitemQuantity(3);
        gl.add(I2);
        System.out.println(gl.getTotalCost());
    }
}
