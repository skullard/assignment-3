import java.util.ArrayList;

public class GroceryList {
    ArrayList<GroceryitemOrder> list;
    int no_of_items = 0;

    public GroceryList() {
    }

    public ArrayList<GroceryitemOrder> getList() {
        return list;
    }

    public void setList(ArrayList<GroceryitemOrder> list) {
        this.list = list;
    }

    public int getNo_of_items() {
        return no_of_items;
    }

    public void setNo_of_items(int no_of_items) {
        this.no_of_items = no_of_items;
    }

    public void add(GroceryitemOrder item) {
        list.add(item);
        no_of_items++;
    }

    public double getTotalCost() {
        double totalCost = 0;
        for (int i = 0; i < list.size(); i++) {
            totalCost += list.get(i).getCost();
        }
        return totalCost;
    }

}
