import java.util.Scanner;
import java.util.ArrayList;

class Main {
    public static void main() {
        ArrayList<Integer> x = new ArrayList<Integer>(10);
        sort(x);
    }

    public static void sort(ArrayList<Integer> x) {
        int y, i, no_of_loobs = x.size(), c = 0;
        for (c = 0; c < no_of_loobs; c++) {
            for (i = 0; i < (x.size() - 1); i++) {
                if (x.get(i) > x.get(i + 1)) {
                    y = x.get(i);
                    x.set(i, x.get(i + 1));
                    x.set(i + 1, y);
                }
            }
        }
    }
}
