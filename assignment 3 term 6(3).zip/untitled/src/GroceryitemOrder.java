public class GroceryitemOrder {
    String item_Name;
    int item_Quantity;
    double item_Price;

    public String getitemName() {
        return item_Name;
    }

    public void setitemName(String x) {
        item_Name = x;
    }

    public int getitemQuantity() {
        return item_Quantity;
    }

    public double getitemPrice() {
        return item_Price;
    }

    public void setitemPrice(double x) {
        item_Price = x;
    }

    public GroceryitemOrder(String x, double y) {
        item_Name = x;
        item_Quantity = 1;
        item_Price = y;
    }


    public double getCost() {
        return item_Price * item_Quantity;
    }

    public void setitemQuantity(int Quantity) {
        item_Quantity = Quantity;
    }
}
